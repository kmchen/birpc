go-bidirpc
==========

Bidirectional RPC for Go.
See the examples for the Usage.
